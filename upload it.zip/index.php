

<!DOCTYPE html>
<html>
<link rel="stylesheet" href="app.css">
<body>

<div class="center">

<div class="kati">
  <h1>DEPOSIT TO CLIENT<H1>
<form action="test.php" method="post">
Enter amount:

<input class="input" type="number" name="amount" required>
<br><br>
Enter Phone:
<input class="input" type="number" name="phone" required>
<br><br>

<input id="popup" class="btn" type="submit" name="submit">

</form>
</div>
</div>
<script>
document.getElementById("popup").innerHTML =
"The full URL of this page is:<br>" + window.location.href;
</script>
</body>
</html>
