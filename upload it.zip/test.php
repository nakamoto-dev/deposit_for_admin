<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "full_web";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}
// end of connection
$amount = $_POST['amount'];
$phone = $_POST['phone'];




$sql = "SELECT phone FROM users WHERE phone = $phone";
$result = $conn->query($sql);

if ( $result->num_rows > 0 ) {

// do something
$sql = "UPDATE users SET balance= balance + $amount WHERE phone= $phone";

if ($conn->query($sql) === TRUE) {
  echo "Record updated successfully";

  header("Location: index.php");

} else {
  echo "Error updating record: " . $conn->error;
}

// end





  }

else {
  echo "0 results";
    header("Location: notfound.php");
}

$conn->close();




?>
